const tasksLocal = [];
document.getElementById('taskForm').addEventListener('submit', e=>{
  e.preventDefault();
  const t = {
    title: document.getElementById('title').value,
    due_date: document.getElementById('due_date').value || null,
    estimated_hours: parseFloat(document.getElementById('estimated_hours').value||0),
    importance: parseFloat(document.getElementById('importance').value||5),
    dependencies: (document.getElementById('dependencies').value||'').split(',').map(s=>s.trim()).filter(s=>s).map(x=>isNaN(x)?x:parseInt(x))
  };
  tasksLocal.push(t);
  alert('Task added to local list. Click Analyze to send to API.');
});
function strategyWeights(strategy){
  // map the frontend selection to weights matching backend DEFAULT_WEIGHTS keys
  switch(strategy){
    case 'fast': return {'urgency':0.2,'importance':0.1,'effort':0.6,'dependency':0.1};
    case 'impact': return {'urgency':0.1,'importance':0.7,'effort':0.05,'dependency':0.15};
    case 'deadline': return {'urgency':0.7,'importance':0.1,'effort':0.1,'dependency':0.1};
    default: return null;
  }
}
document.getElementById('analyzeBtn').addEventListener('click', async ()=>{
  let tasks = [];
  try{
    const bulk = document.getElementById('bulk').value.trim();
    if(bulk) tasks = JSON.parse(bulk);
  }catch(err){ alert('Invalid JSON in bulk input'); return; }
  tasks = tasks.concat(tasksLocal);
  if(!tasks.length){ alert('No tasks provided'); return; }
  const strat = document.getElementById('strategy').value;
  const weights = strategyWeights(strat);
  const payload = Array.isArray(tasks) ? {tasks, weights} : tasks;
  const res = await fetch('/api/tasks/analyze/', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!res.ok){ alert('API error'); return; }
  const data = await res.json();
  displayResults(data.tasks);
      try{ tasksForGraph = data.tasks.map((t,idx)=>({id:t.id ?? idx, title:t.title, dependencies:t.dependencies||[]})); if(typeof renderGraph==='function') renderGraph(tasksForGraph);}catch(e){};
});
document.getElementById('suggestBtn').addEventListener('click', async ()=>{
  let tasks = [];
  try{
    const bulk = document.getElementById('bulk').value.trim();
    if(bulk) tasks = JSON.parse(bulk);
  }catch(err){ alert('Invalid JSON in bulk input'); return; }
  tasks = tasks.concat(tasksLocal);
  if(!tasks.length){ alert('No tasks provided'); return; }
  const res = await fetch('/api/tasks/suggest/', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tasks})});
  if(!res.ok){ alert('API error'); return; }
  const data = await res.json();
  displaySuggestions(data.suggestions || data.suggestions);
});
function displayResults(tasks){
  const out = document.getElementById('results'); out.innerHTML='';
  tasks.forEach(t=>{
    const el = document.createElement('div'); el.className='task';
    if(t.score>=75) el.classList.add('high');
    else if(t.score>=40) el.classList.add('medium'); else el.classList.add('low');
    el.innerHTML = `<strong>${t.title}</strong> — Score: ${t.score}<br><small>${t.reason||''}</small><pre>${JSON.stringify(t,null,2)}</pre>`;
    out.appendChild(el);
  });
}
function displaySuggestions(s){
  // s: array of suggestions
  const out = document.getElementById('results'); out.innerHTML='';
  s.forEach(x=>{
    const el = document.createElement('div'); el.className='task';
    el.innerHTML = `<strong>${x.title}</strong> — Score: ${x.score}<br><small>${x.explanation||''}</small>`;
    out.appendChild(el);
  });
}
