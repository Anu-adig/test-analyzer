(function(global){
  // Expose renderGraph to global for dynamic rendering
  function renderGraph(tasksForGraph){
    if(typeof d3 === 'undefined'){
      console.warn('D3 not loaded');
      return;
    }
    // clear previous svg
    const container = d3.select("#graph");
    container.selectAll("*").remove();
    if(!tasksForGraph || tasksForGraph.length===0){
      container.append("div").text("No tasks to display.");
      return;
    }
    const nodes = tasksForGraph.map(t => ({id: t.id ?? t.title, title: t.title}));
    const links = [];
    tasksForGraph.forEach(t=>{
      const src = t.id ?? t.title;
      (t.dependencies||[]).forEach(d=>{
        links.push({source: d, target: src});
      });
    });
    const width = Math.min(900, Math.max(600, window.innerWidth*0.8)), height = 400;
    const svg = container.append("svg").attr("width", width).attr("height", height);
    const simulation = d3.forceSimulation(nodes)
        .force("link", d3.forceLink(links).id(d => d.id).distance(80))
        .force("charge", d3.forceManyBody().strength(-300))
        .force("center", d3.forceCenter(width/2, height/2));
    const link = svg.append("g").selectAll("line").data(links).enter().append("line").style("stroke","#999");
    const node = svg.append("g").selectAll("g").data(nodes).enter().append("g");
    node.append("circle").attr("r",10).style("fill","#1976d2");
    node.append("text").attr("x",12).attr("y",4).text(d=>d.title);
    simulation.on("tick",()=>{
      link.attr("x1",d=>d.source.x).attr("y1",d=>d.source.y).attr("x2",d=>d.target.x).attr("y2",d=>d.target.y);
      node.attr("transform",d=>`translate(${d.x},${d.y})`);
    });
  }
  global.renderGraph = renderGraph;
})(window);
