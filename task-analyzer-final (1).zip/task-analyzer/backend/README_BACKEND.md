# Backend README - Algorithm Explanation & Design Decisions

## Priority Scoring Algorithm (Explanation)
The scoring algorithm computes a numeric priority score for each task by combining four primary factors: urgency, importance, effort, and dependency impact. Each factor is normalized to a 0–1 range and then combined using configurable weights. The resulting aggregate is scaled to a 0–100 score to make it human-friendly.

Urgency measures how soon a task is due. If a task has no due date, urgency is treated as low (0.1). If the due date is in the future, urgency is computed as `max(0, 1 - days_until_due / 30)`, so tasks due today score near 1 and tasks due 30+ days away approach 0. Past-due tasks receive a boosted urgency (>1) that increases proportionally with days overdue (with a practical cap), ensuring overdue work jumps to the top of the list.

Importance uses the user-provided 1–10 rating mapped to a 0–1 scale. Effort is inverted: lower estimated hours increase the score (quick wins are favored when the 'effort' weight is high). Specifically, effort maps hours to a 0–1 score where 0 hours → 1.0 and 8+ hours → 0.0 (capped).

Dependency impact rewards tasks that block other tasks. We compute how many tasks depend on a given task and normalize that count—blocking multiple tasks increases priority because completing that task unblocks more work.

The final score is computed as a weighted sum of these factors. We provide sensible default weights (`urgency:0.4`, `importance:0.3`, `effort:0.15`, `dependency:0.15`) and allow strategy presets (Fastest Wins, High Impact, Deadline Driven) to override these weights from the frontend. The design choice to keep weights configurable lets the user tailor the prioritization to their workflow.

## Handling Edge Cases
- **Missing due date**: treated as low urgency rather than invalid input.
- **Invalid or missing numeric fields**: validated on input; errors return clear messages.
- **Past-due tasks**: boosted urgency to ensure attention while preserving other factors.
- **Circular dependencies**: a cycle detection algorithm (Kahn's algorithm) flags cycles in the input; the response includes a `has_cycle` boolean so the UI can highlight the issue.

## Trade-offs & Design Decisions
- I chose a simple, explainable scoring model (weighted linear combination) to make behavior predictable and easy to justify in a README.
- Alternatives include multi-objective ranking or machine learning; those add complexity and data requirements that don't fit the assignment constraints.
- The system is deliberately stateless (no DB) to simplify running locally and focusing on algorithm quality.

## Future Improvements
- Add time-off/holidays calendar awareness when computing urgency.
- Learn weights from user feedback (reinforcement or supervised learning).
- Visualize dependency graph and flag circular dependencies in the UI.
