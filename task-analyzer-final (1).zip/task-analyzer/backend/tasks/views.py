import json
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from .scoring import analyze_tasks, suggest_top, DEFAULT_WEIGHTS
from .serializers import validate_task
from datetime import date

@csrf_exempt
def analyze_tasks(request):
    if request.method != 'POST':
        return HttpResponseBadRequest(json.dumps({'error': 'POST required'}), content_type='application/json')
    try:
        body = json.loads(request.body.decode('utf-8'))
        tasks = body if isinstance(body, list) else body.get('tasks', [])
        weights = body.get('weights', DEFAULT_WEIGHTS) if isinstance(body, dict) else DEFAULT_WEIGHTS
        # validate tasks
        for t in tasks:
            validate_task(t)
        res = analyze_tasks(tasks, weights=weights, today=date.today())
        return JsonResponse(res, safe=False)
    except Exception as e:
        return HttpResponseBadRequest(json.dumps({'error': str(e)}), content_type='application/json')

@csrf_exempt
def suggest_tasks(request):
    # allow GET or POST with optional body
    try:
        if request.method == 'GET':
            # no body; we'll look for query param 'tasks' containing JSON array
            tasks_json = request.GET.get('tasks')
            tasks = json.loads(tasks_json) if tasks_json else []
        else:
            body = json.loads(request.body.decode('utf-8') or '{}')
            tasks = body.get('tasks', [])
        for t in tasks:
            validate_task(t)
        suggestions = suggest_top(tasks, top_n=3, today=date.today())
        return JsonResponse({'suggestions': suggestions}, safe=False)
    except Exception as e:
        return HttpResponseBadRequest(json.dumps({'error': str(e)}), content_type='application/json')
