# Simple serializer-like validation (no DRF Serializer to keep dependency small)
from datetime import datetime
def validate_task(task):
    # Required fields: title, due_date, estimated_hours, importance, dependencies
    if 'title' not in task:
        raise ValueError('Task missing title')
    # due_date optional: if present, ensure valid ISO date
    if 'due_date' in task and task['due_date']:
        try:
            datetime.fromisoformat(task['due_date'])
        except Exception:
            raise ValueError('Invalid due_date format, expected ISO date')
    if 'estimated_hours' in task and task['estimated_hours'] is not None:
        if not isinstance(task['estimated_hours'], (int,float)):
            raise ValueError('estimated_hours must be a number')
    if 'importance' in task:
        imp = task['importance']
        if not (isinstance(imp,int) or isinstance(imp,float)) or not (1 <= imp <= 10):
            raise ValueError('importance must be numeric between 1 and 10')
    if 'dependencies' in task and not isinstance(task['dependencies'], list):
        raise ValueError('dependencies must be a list')
    return True
