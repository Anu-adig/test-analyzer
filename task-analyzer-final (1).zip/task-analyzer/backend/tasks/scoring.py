from datetime import datetime, date, timedelta
from collections import defaultdict, deque

DEFAULT_WEIGHTS = {
    'urgency': 0.4,
    'importance': 0.3,
    'effort': 0.15,
    'dependency': 0.15
}

def parse_date(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s).date()
    except Exception:
        return None

def detect_cycles(tasks):
    # tasks: list of dicts, id assumed via index or provided 'id'
    id_map = {}
    for i, t in enumerate(tasks):
        tid = t.get('id', i)
        id_map[tid] = t
    # build graph
    graph = defaultdict(list)
    for tid, t in id_map.items():
        for dep in t.get('dependencies', []):
            # edge dep -> tid (dep must be done before tid)
            graph[dep].append(tid)
    # detect cycle via Kahn's algorithm
    indeg = defaultdict(int)
    nodes = set(id_map.keys())
    for u in nodes:
        for v in graph.get(u, []):
            indeg[v] += 1
    q = deque([n for n in nodes if indeg[n]==0])
    visited = 0
    while q:
        u = q.popleft()
        visited += 1
        for v in graph.get(u, []):
            indeg[v] -= 1
            if indeg[v]==0:
                q.append(v)
    return visited != len(nodes)

def compute_score(task, tasks_by_id=None, weights=None, today=None):
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if today is None:
        today = date.today()
    # parse fields
    due = parse_date(task.get('due_date'))
    importance = float(task.get('importance', 5))
    effort = float(task.get('estimated_hours', 4))
    deps = task.get('dependencies', [])
    # URGENCY: normalized 0..1. Past-due => 1. If no due date => 0.1
    if due is None:
        urgency = 0.1
    else:
        days = (due - today).days
        if days < 0:
            urgency = 1.0 + min(abs(days)/30.0, 1.0)  # late tasks boosted up to 2.0 cap
        else:
            # scale: due today => 1, due in 30+ days => 0
            urgency = max(0.0, 1 - (days / 30.0))
    # IMPORTANCE: 1-10 mapped to 0..1
    importance_score = max(0.0, min(1.0, (importance - 1) / 9.0))
    # EFFORT: lower effort should increase priority; we'll invert and cap
    # Assume effort in hours; map effort 0..8+ => effort_score 1..0
    effort_score = 1.0 - (min(effort, 8.0) / 8.0)
    # DEPENDENCY: tasks that block many others get higher score
    dep_score = 0.0
    if tasks_by_id:
        # count how many tasks depend on this task
        tid = task.get('id')
        if tid is not None:
            count = sum(1 for t in tasks_by_id.values() if tid in t.get('dependencies', []))
            # normalize by a simple logistic-like mapping
            dep_score = min(1.0, count / 3.0)
    else:
        dep_score = min(1.0, len(deps) / 3.0)
    # Combine with weights
    # Note: if urgency >1 (past-due boosted) we allow it to dominate but then normalize final
    raw = (weights['urgency'] * urgency +
           weights['importance'] * importance_score +
           weights['effort'] * effort_score +
           weights['dependency'] * dep_score)
    # Normalize to 0..100 scale
    score = max(0.0, min(1.0, raw)) * 100.0
    return round(score, 2)

def analyze_tasks(tasks, weights=None, today=None):
    # tasks: list of dicts; ensure ids
    tasks_by_id = {}
    for i, t in enumerate(tasks):
        if 'id' not in t:
            t['id'] = i
        tasks_by_id[t['id']] = t
    # detect cycles
    has_cycle = detect_cycles(tasks)
    results = []
    for t in tasks:
        sc = compute_score(t, tasks_by_id=tasks_by_id, weights=weights, today=today)
        reason = generate_reason(t, sc, today=today)
        results.append({**t, 'score': sc, 'reason': reason})
    # sort by score desc
    results.sort(key=lambda x: x['score'], reverse=True)
    return {'has_cycle': has_cycle, 'tasks': results}

def suggest_top(tasks, top_n=3, weights=None, today=None):
    res = analyze_tasks(tasks, weights=weights, today=today)
    suggestions = []
    for t in res['tasks'][:top_n]:
        suggestions.append({
            'id': t['id'],
            'title': t['title'],
            'score': t['score'],
            'explanation': t.get('reason')
        })
    return suggestions

def generate_reason(task, score, today=None):
    today = today or date.today()
    parts = []
    due = parse_date(task.get('due_date'))
    if due:
        days = (due - today).days
        if days < 0:
            parts.append(f'Past due by {abs(days)} day(s) — urgency is high.')
        elif days == 0:
            parts.append('Due today — urgency is high.')
        elif days <= 3:
            parts.append(f'Due in {days} days — urgent.')
        else:
            parts.append(f'Due in {days} days.')
    else:
        parts.append('No due date provided — treated as low urgency.')
    parts.append(f'Importance: {task.get("importance", "N/A")} (1-10).')
    parts.append(f'Estimated effort: {task.get("estimated_hours", "N/A")} hours.')
    if task.get('dependencies'):
        parts.append(f'Has {len(task.get("dependencies"))} dependency(ies).')
    return ' '.join(parts)
