from backend.tasks.scoring import analyze_tasks, compute_score, suggest_top
from datetime import date, timedelta
def test_compute_score_basic():
    today = date.today()
    t = {'title':'A','due_date':(today+timedelta(days=1)).isoformat(),'estimated_hours':2,'importance':8,'dependencies':[],'id':1}
    sc = compute_score(t,tasks_by_id={1:t},today=today)
    assert sc>0 and sc<=100
def test_analyze_sorts():
    today = date.today()
    tasks = [
        {'title':'low','due_date':(today+timedelta(days=30)).isoformat(),'estimated_hours':8,'importance':3,'dependencies':[]},
        {'title':'high','due_date':(today+timedelta(days=1)).isoformat(),'estimated_hours':1,'importance':9,'dependencies':[]},
    ]
    res = analyze_tasks(tasks,today=today)
    assert res['tasks'][0]['title']=='high'
def test_suggest_top_length():
    tasks = [{'title':'a','importance':5,'estimated_hours':1,'dependencies':[]},
             {'title':'b','importance':6,'estimated_hours':2,'dependencies':[]},
             {'title':'c','importance':7,'estimated_hours':3,'dependencies':[]},
             {'title':'d','importance':8,'estimated_hours':4,'dependencies':[]}]
    s = suggest_top(tasks, top_n=3)
    assert len(s)==3
